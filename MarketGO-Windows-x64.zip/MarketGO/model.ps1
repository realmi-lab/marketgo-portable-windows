$Venues=@('bithumb','upbit','coinone','korbit','gopax')
function Kst-Day { [DateTime]::UtcNow.AddHours(9).ToString('yyyy-MM-dd') }
function New-Cell { return @{total=$null;krw=$null;btc=$null;usdt=$null;share=$null;partial=$false;unavailable=$false} }
function Add-Cell($cell,$amount,$partial) {
    if($null -ne $amount){if($null -eq $cell.total){$cell.total=0.0};$cell.total+=[double]$amount;$cell.krw=$cell.total}
    if($partial -or $null -eq $amount){$cell.partial=$true}
    if($null -eq $amount){$cell.unavailable=$true}
}
function Finish-Cells($cells,$domesticTotal,$isTotal) {
    $all=New-Cell; $combined=New-Cell
    foreach($venue in $Venues){if($cells.ContainsKey($venue)){$c=$cells[$venue];Add-Cell $all $c.total $c.partial;if($venue -in @('bithumb','upbit')){Add-Cell $combined $c.total $c.partial}}}
    $cells['domestic']=$all;$cells['combined']=$combined
    foreach($venue in @($Venues)+@('combined')){if($cells.ContainsKey($venue) -and $null -ne $cells[$venue].total -and $all.total -gt 0){$cells[$venue].share=100.0*$cells[$venue].total/$all.total}}
    if($isTotal){$domesticTotal=$all.total}
    if($null -ne $all.total -and $domesticTotal -gt 0){$all.share=100.0*$all.total/$domesticTotal}
}
function Build-Grid($rows,$query) {
    $coins=@{};$totals=@{};$assetFilter=@{}
    if($query.ContainsKey('assets')){foreach($asset in $query.assets.Split(',')){$assetFilter[$asset]=$true}}
    foreach($row in $rows){
        if($query.ContainsKey('assets') -and -not $assetFilter.ContainsKey($row.base)){continue}
        if($query.quote -and $query.quote -notin @('all','krw','KRW')){continue}
        if($query.venue -and $query.venue -ne 'all' -and $query.venue -ne $row.exchange -and -not($query.venue -eq 'combined' -and $row.exchange -in @('bithumb','upbit'))){continue}
        if(-not $coins.ContainsKey($row.base)){$coins[$row.base]=@{}}
        if(-not $coins[$row.base].ContainsKey($row.exchange)){$coins[$row.base][$row.exchange]=New-Cell}
        if(-not $totals.ContainsKey($row.exchange)){$totals[$row.exchange]=New-Cell}
        Add-Cell $coins[$row.base][$row.exchange] $row.volume_krw ($row.status -ne 'COMPLETE')
        Add-Cell $totals[$row.exchange] $row.volume_krw ($row.status -ne 'COMPLETE')
    }
    Finish-Cells $totals $null $true
    $list=[Collections.Generic.List[object]]::new()
    foreach($base in $coins.Keys){Finish-Cells $coins[$base] $totals.domestic.total $false;$list.Add(@{base=$base;cells=$coins[$base]})}
    return @{totals=$totals;coins=@($list.ToArray()|Sort-Object @{Expression={if($null -eq $_.cells.domestic.total){-1}else{$_.cells.domestic.total}};Descending=$true},base)}
}
function New-Row($venue,$base,$amount,$partial) {
    return @{exchange=$venue;base=$base;market="KRW-$base";quote='KRW';volume_krw=$amount;quote_volume=$amount;hours=0;amount_hours=0;base_volume=$null;status=$(if($partial){'PARTIAL'}else{'COMPLETE'});sources=@('POWERSHELL_OFFICIAL')}
}
function Get-TickerIndex($query,$shared) {
    if($query.day -and $query.day -ne (Kst-Day)){throw 'This PowerShell package has no archived hourly candles. Select today.'}
    $rows=[Collections.Generic.List[object]]::new();$now=Now-Seconds;$oldest=$now;$partial=$false
    foreach($venue in $Venues){
        $ticker=$shared.Tickers[$venue]
        $valid=$ticker -and $ticker.at -gt $now-30 -and -not $ticker.error
        if(-not $valid){$partial=$true}
        if($ticker){$oldest=[Math]::Min($oldest,[long]$ticker.at)}
        foreach($r in $ticker.rows){$amount=$null;if($valid){$amount=$r.amount};$rows.Add((New-Row $venue $r.base $amount (-not $valid)))}
    }
    $grid=Build-Grid $rows.ToArray() $query
    if($partial){foreach($cell in $grid.totals.Values){$cell.partial=$true}}
    return @{contract_version='INDEX_TICKER_V1';storage_mode='TICKER_24H';day=(Kst-Day);start=$oldest-86400;end=$oldest;status=$(if($partial){'PARTIAL'}else{'COMPLETE'});membership='CURRENT_KRW_MARKETS';usdt_close_krw=$null;rows=$rows.ToArray();exchanges=@();domestic=$grid}
}
function Get-Live($seconds,$end,$shared) {
    $rows=[Collections.Generic.List[object]]::new();$exchangeRows=[Collections.Generic.List[object]]::new();$coverage=$seconds;$total=0.0;$tradeTotal=0;$complete=$true
    foreach($venue in $Venues){
        $feeds=@($shared.Feeds.Values|Where-Object {$_.venue -eq $venue})
        $since=$end+1;$available=$false
        if($feeds.Count -gt 0){
            $available=@($feeds|Where-Object {$_.state -notin @('LIVE','WAITING') -or $_.at -lt $end-90}).Count -eq 0
            # Windows PowerShell 5.1 Measure-Object cannot resolve hashtable
            # keys as properties. Read the timestamps explicitly instead.
            $since=0L
            foreach($feed in $feeds){$connectedAt=[long]$feed['since'];if($connectedAt -gt $since){$since=$connectedAt}}
        }
        $since=[Math]::Max($since,[long]$shared.Retained[$venue])
        $covered=[Math]::Max(0,[Math]::Min($seconds,$end-$since))
        $partial=(-not $available) -or $covered -lt $seconds -or @($feeds|Where-Object {$_.state -ne 'LIVE'}).Count -gt 0
        if($partial){$complete=$false};$coverage=[Math]::Min($coverage,$covered)
        $assets=@{};$amount=0.0;$count=0
        foreach($entry in $shared.Buckets[$venue].GetEnumerator()){
            $split=$entry.Key.IndexOf('|');$at=[long]$entry.Key.Substring(0,$split)
            if($at -le $end-$seconds -or $at -gt $end){continue}
            $base=$entry.Key.Substring($split+1)
            if(-not $assets.ContainsKey($base)){$assets[$base]=@(0.0,0)}
            $assets[$base][0]+=[double]$entry.Value[0];$assets[$base][1]+=[long]$entry.Value[1]
            $amount+=[double]$entry.Value[0];$count+=[long]$entry.Value[1]
        }
        foreach($base in $assets.Keys){$rows.Add((New-Row $venue $base $assets[$base][0] $partial))}
        $reported=$null
        if($count -gt 0 -or (-not $partial)){$reported=$amount;$total+=$amount;$tradeTotal+=$count}
        $exchangeRows.Add(@{exchange=$venue;volume_krw=$reported;trade_count=$(if($null -ne $reported){$count}else{$null});share_pct=$null;trade_count_share_pct=$null;partial=$partial})
    }
    foreach($row in $exchangeRows){if($null -ne $row.volume_krw -and $total -gt 0){$row.share_pct=$row.volume_krw*100.0/$total};if($null -ne $row.trade_count -and $tradeTotal -gt 0){$row.trade_count_share_pct=$row.trade_count*100.0/$tradeTotal}}
    return @{rows=$rows.ToArray();exchanges=$exchangeRows.ToArray();complete=$complete;coverage=$coverage;total=$total}
}
function Get-LiveCached($seconds,$end,$shared){
    $key="$seconds|$end"
    if(-not $script:LiveCache.ContainsKey($key)){$script:LiveCache[$key]=Get-Live $seconds $end $shared}
    return $script:LiveCache[$key]
}
function Get-RealtimeIndex($query,$shared){
    $seconds=Read-Window $query;$end=(Now-Seconds)-1;$live=Get-LiveCached $seconds $end $shared
    return @{contract_version='REALTIME_INDEX_V1';storage_mode='REALTIME_WINDOW';day=(Kst-Day);start=$end-$seconds+1;end=$end+1;as_of_second=$end;window_sec=$seconds;coverage_sec=$live.coverage;window_complete=$live.complete;status=$(if($live.complete){'COMPLETE'}else{'PARTIAL'});membership='OBSERVED_KRW_TRADES';usdt_close_krw=$null;rows=@();exchanges=@();domestic=(Build-Grid $live.rows $query)}
}
function Read-Window($query){
    $seconds=10
    if($query.window){$seconds=[int]$query.window}
    if($seconds -notin @(10,30,60,300,600,1800,3600,7200,14400,21600,43200,86400)){throw 'Unsupported window'}
    return $seconds
}
function Get-State($query,$shared){
    $seconds=Read-Window $query;$end=(Now-Seconds)-1;$live=Get-LiveCached $seconds $end $shared
    $before=Get-LiveCached $seconds ($end-$seconds) $shared
    $changes=@()
    foreach($current in $live.exchanges){
        $prior=@($before.exchanges|Where-Object {$_.exchange -eq $current.exchange})[0]
        $delta=$null;$shareDelta=$null
        if($null -ne $current.volume_krw -and $null -ne $prior.volume_krw){$delta=$current.volume_krw-$prior.volume_krw}
        if($null -ne $current.share_pct -and $null -ne $prior.share_pct){$shareDelta=$current.share_pct-$prior.share_pct}
        $changes+=@{exchange=$current.exchange;amount=$current.volume_krw;delta=$delta;before=$prior.share_pct;after=$current.share_pct;share_delta=$shareDelta}
    }
    $strip=@()
    foreach($w in @(10,30,60,600,1800,3600)){$value=Get-LiveCached $w $end $shared;$row=@($value.exchanges|Where-Object {$_.exchange -eq 'bithumb'})[0];$strip+=@{window=$w;share=$row.share_pct;partial=(-not $value.complete)}}
    $connections=@()
    foreach($venue in $Venues){$ticker=$shared.Tickers[$venue];$connections+=@{exchange=$venue;ticker_at=$ticker.at;ticker_error=$ticker.error;feeds=@($shared.Feeds.Values|Where-Object {$_.venue -eq $venue})}}
    $point=@{at=($end+1)*1000}
    if(-not $live.complete){$point.partial=1}
    if($seconds -eq 86400){
        $ticker=Get-TickerIndex @{} $shared;$point.at=$ticker.end*1000
        $officialRows=@()
        foreach($venue in $Venues){$cell=$ticker.domestic.totals[$venue];$point["share_$venue"]=$cell.share;$officialRows+=@{exchange=$venue;volume_krw=$cell.total;share_pct=$cell.share;trade_count=$null;trade_count_share_pct=$null;partial=$cell.partial}}
        $live.exchanges=$officialRows
        foreach($change in $changes){$cell=$ticker.domestic.totals[$change.exchange];$change.amount=$cell.total;$change.after=$cell.share;$change.before=$null;$change.delta=$null;$change.share_delta=$null}
    }else{foreach($row in $live.exchanges){$point["share_$($row.exchange)"]=$row.share_pct}}
    return @{at=$end;window=$seconds;exchanges=$live.exchanges;changes=$changes;strip=$strip;point=$point;connections=$connections;partial=(-not $live.complete)}
}
function Get-Filters($shared){
    $byAsset=@{}
    foreach($venue in $Venues){foreach($row in $shared.Tickers[$venue].rows){if(-not $byAsset.ContainsKey($row.base)){$byAsset[$row.base]=@()};$byAsset[$row.base]+=$venue}}
    $assets=@(foreach($base in $byAsset.Keys){$venues=$byAsset[$base];@{asset=$base;listed_on_bithumb=('bithumb' -in $venues);exclusive_on_bithumb=($venues.Count -eq 1 -and 'bithumb' -in $venues);shared_bithumb_upbit=('bithumb' -in $venues -and 'upbit' -in $venues)}})
    return @{contract_version='INDEX_FILTERS_V1';assets=$assets;notice_assets=@()}
}
