$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
function Now-Seconds { [long][Math]::Floor(([DateTime]::UtcNow - [DateTime]'1970-01-01').TotalSeconds) }
function Number($value) {
    if ($null -eq $value) { throw 'Missing numeric field' }
    $n = [double]::Parse([string]$value, [Globalization.CultureInfo]::InvariantCulture)
    if ([double]::IsNaN($n) -or [double]::IsInfinity($n) -or $n -lt 0) { throw 'Invalid numeric field' }
    return $n
}
function Read-Tickers($venue, $json) {
    $result = [Collections.Generic.List[object]]::new()
    switch ($venue) {
        'bithumb' {
            if ($json.status -ne '0000') { throw 'Bithumb rejected ticker request' }
            foreach ($p in $json.data.PSObject.Properties) {
                if ($p.Name -eq 'date') { continue }
                $result.Add(@{base=$p.Name;symbol="KRW-$($p.Name)";amount=(Number $p.Value.acc_trade_value_24H)})
            }
        }
        'upbit' { foreach ($r in $json) { if ($r.market -like 'KRW-*') { $result.Add(@{base=$r.market.Substring(4);symbol=$r.market;amount=(Number $r.acc_trade_price_24h)}) } } }
        'coinone' {
            if ($json.result -ne 'success') { throw 'Coinone rejected ticker request' }
            foreach ($r in $json.tickers) { if ($r.quote_currency -eq 'KRW') { $result.Add(@{base=$r.target_currency;symbol="KRW-$($r.target_currency)";amount=(Number $r.quote_volume)}) } }
        }
        'korbit' {
            if ($json.success -ne $true) { throw 'DigitalX rejected ticker request' }
            foreach ($r in $json.data) { if ($r.symbol -like '*_krw') { $result.Add(@{base=$r.symbol.Replace('_krw','').ToUpperInvariant();symbol=$r.symbol;amount=(Number $r.quoteVolume)}) } }
        }
        'gopax' { foreach ($r in $json) { if ($r.tradingPairName -like '*-KRW') { $result.Add(@{base=$r.tradingPairName.Replace('-KRW','');symbol=$r.tradingPairName;amount=(Number $r.quoteVolume)}) } } }
    }
    if ($result.Count -eq 0) { throw 'Empty ticker response' }
    $seen = @{}
    foreach ($r in $result) { if ($seen.ContainsKey($r.base)) { throw 'Duplicate ticker market' }; $seen[$r.base]=$true }
    return ,$result.ToArray()
}
function Run-Ticker($venue, $shared) {
    $urls=@{bithumb='https://api.bithumb.com/public/ticker/ALL_KRW';upbit='https://api.upbit.com/v1/ticker/all?quote_currencies=KRW';coinone='https://api.coinone.co.kr/public/v2/ticker_new/KRW';korbit='https://api.digitalx.miraeasset.com/v2/tickers';gopax='https://api.gopax.co.kr/tickers'}
    $registryUrls=@{bithumb='https://api.bithumb.com/v1/market/all?isDetails=true';upbit='https://api.upbit.com/v1/market/all?is_details=true';coinone='https://api.coinone.co.kr/public/v2/markets/KRW';korbit='https://api.digitalx.miraeasset.com/v2/currencyPairs';gopax='https://api.gopax.co.kr/trading-pairs'}
    $registry=@{};$registryAt=0
    while (-not $shared.Stop) {
        try {
            if((Now-Seconds)-$registryAt -gt 300){
                $listing=Invoke-RestMethod -Uri $registryUrls[$venue] -TimeoutSec 8
                $next=@{}
                switch($venue){
                    {$_ -in @('bithumb','upbit')}{foreach($r in $listing){if($r.market -like 'KRW-*'){$next[$r.market.Substring(4)]=$r.market}}}
                    'coinone'{foreach($r in $listing.markets){if($r.trade_status -in @(1,2,3)){$next[$r.target_currency]="KRW-$($r.target_currency)"}}}
                    'korbit'{foreach($r in $listing.data){if($r.status -eq 'launched' -and $r.symbol -like '*_krw'){$next[$r.symbol.Replace('_krw','').ToUpperInvariant()]=$r.symbol}}}
                    'gopax'{foreach($r in $listing){if($r.quoteAsset -eq 'KRW'){$next[$r.baseAsset]=$r.name}}}
                }
                if($next.Count -eq 0){throw 'Empty official market registry'}
                $registry=$next;$registryAt=Now-Seconds
            }
            $raw=Invoke-RestMethod -Uri $urls[$venue] -TimeoutSec 8 -UserAgent 'MarketGO-Portable/2.0'
            $rows=@((Read-Tickers $venue $raw)|Where-Object {$registry.ContainsKey($_.base)})
            if($rows.Count -ne $registry.Count){throw "Ticker market coverage mismatch: $($rows.Count)/$($registry.Count)"}
            $shared.Tickers[$venue]=@{rows=$rows;at=(Now-Seconds);error=''}
        } catch {
            $old=$shared.Tickers[$venue]
            $shared.Tickers[$venue]=@{rows=$(if($old){$old.rows}else{@()});at=$(if($old){$old.at}else{0});error=$_.Exception.Message}
            $shared.Errors.Enqueue("$venue ticker: $($_.Exception.Message)")
        }
        for($i=0;$i -lt 100 -and -not $shared.Stop;$i++){Start-Sleep -Milliseconds 100}
    }
}
function Send-WS($socket,$payload) {
    $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
    $cts=[Threading.CancellationTokenSource]::new(5000)
    try {$socket.SendAsync([ArraySegment[byte]]::new($bytes),[Net.WebSockets.WebSocketMessageType]::Text,$true,$cts.Token).GetAwaiter().GetResult()} finally {$cts.Dispose()}
}
function Get-TradeRows($venue,$raw) {
    $out=[Collections.Generic.List[object]]::new()
    switch($venue) {
        {$_ -in @('upbit','bithumb')} {
            if($raw.type -eq 'trade') {$out.Add(@{base=$raw.code.Substring(4);id=[string]$raw.sequential_id;at=$raw.trade_timestamp;price=$raw.trade_price;qty=$raw.trade_volume})}
        }
        'coinone' {
            if($raw.channel -eq 'TRADE' -and $raw.data -and $raw.data.quote_currency -eq 'KRW') {
                $r=$raw.data; $out.Add(@{base=$r.target_currency;id=[string]$r.id;at=$r.timestamp;price=$r.price;qty=$r.qty})
            }
        }
        'korbit' {
            if($raw.type -eq 'trade' -and -not $raw.snapshot) {
                foreach($r in $raw.data) {$out.Add(@{base=$raw.symbol.Replace('_krw','').ToUpperInvariant();id=[string]$r.tradeId;at=$r.timestamp;price=$r.price;qty=$r.qty})}
            }
        }
        'gopax' {
            if($raw.n -eq 'PublicTradeEvent') {
                $r=$raw.o
                $out.Add(@{base=$r.tradingPairName.Replace('-KRW','');id=[string]$r.tradeId;at=$r.occurredAt;price=$r.price;qty=$r.baseAmount})
            }
        }
    }
    return ,$out.ToArray()
}
function Store-Trade($venue,$trade,$connected,$now,$shared) {
    if([string]::IsNullOrEmpty($trade.id)){return $false}
    $stamp=Number $trade.at
    if($stamp -gt 10000000000000){$stamp=$stamp/1000}
    if($stamp -gt 100000000000){$stamp=$stamp/1000}
    $second=[long][Math]::Floor($stamp)
    if($second -lt $connected-2 -or $second -gt $now+5){return $false}
    $amount=(Number $trade.price)*(Number $trade.qty)
    if([double]::IsInfinity($amount)){throw 'Invalid trade amount'}
    if($amount -le 0){return $false}
    $identity="$($trade.base)|$($trade.id)"
    if(-not $shared.Seen[$venue].TryAdd($identity,[long]$now)){return $false}
    $bucket="$second|$($trade.base)"
    $previous=$shared.Buckets[$venue][$bucket]
    if($null -eq $previous){$previous=@(0.0,0)}
    $shared.Buckets[$venue][$bucket]=@(([double]$previous[0]+$amount),([long]$previous[1]+1))
    return $true
}
function Run-Trades($venue,$markets,$key,$shared) {
    $urls=@{bithumb='wss://ws-api.bithumb.com/websocket/v1';upbit='wss://api.upbit.com/websocket/v1';coinone='wss://stream.coinone.co.kr';korbit='wss://ws-api.digitalx.miraeasset.com/v2/public';gopax='wss://wsapi.gopax.co.kr'}
    $dedup=$shared.Seen[$venue]
    $symbols=@($markets | ForEach-Object {$_.symbol})
    $allowed=@{}; foreach($m in $markets){$allowed[$m.base]=$true}
    $retry=1
    while(-not $shared.Stop) {
        $socket=[Net.WebSockets.ClientWebSocket]::new()
        # .NET Framework sends unsolicited pong frames for keep-alive; some
        # exchanges reject them. Use protocol heartbeat and bounded reconnect.
        $socket.Options.KeepAliveInterval=[TimeSpan]::Zero
        $cts=[Threading.CancellationTokenSource]::new(10000)
        try {
            $shared.Feeds[$key]=@{venue=$venue;state='CONNECTING';since=0;at=(Now-Seconds);error=''}
            $socket.ConnectAsync([uri]$urls[$venue],$cts.Token).GetAwaiter().GetResult()
            $connected=Now-Seconds
            switch($venue) {
                {$_ -in @('upbit','bithumb')} {
                    $trade=@{type='trade';codes=$symbols}
                    if($venue -eq 'upbit') {$trade.is_only_realtime=$true} else {$trade.isOnlyRealtime=$true}
                    Send-WS $socket (ConvertTo-Json -InputObject @(@{ticket=[guid]::NewGuid().ToString()},$trade,@{format='DEFAULT'}) -Depth 6 -Compress)
                }
                'coinone' {foreach($m in $markets){Send-WS $socket (@{request_type='SUBSCRIBE';channel='TRADE';topic=@{quote_currency='KRW';target_currency=$m.base}}|ConvertTo-Json -Depth 6 -Compress);Start-Sleep -Milliseconds 25}}
                'korbit' {Send-WS $socket (ConvertTo-Json -InputObject @(@{method='subscribe';type='trade';symbols=$symbols}) -Depth 6 -Compress)}
                'gopax' {$id=0;foreach($m in $markets){$id++;Send-WS $socket (@{i=$id;n='SubscribeToTradingPair';o=@{tradingPairName=$m.symbol;limit=20}}|ConvertTo-Json -Depth 6 -Compress);Start-Sleep -Milliseconds 25}}
            }
            $buffer=New-Object byte[] 65536
            $memory=[IO.MemoryStream]::new()
            $receive=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None)
            $last=Now-Seconds; $ping=$last; $cleanup=$last
            # A connected socket alone is not confirmed trade-channel coverage.
            $confirmed=$false
            while(-not $shared.Stop -and $socket.State -eq [Net.WebSockets.WebSocketState]::Open) {
                $now=Now-Seconds
                if($venue -eq 'coinone' -and $now-$ping -ge 20){Send-WS $socket '{"request_type":"PING"}';$ping=$now}
                if($now-$last -gt 90){throw 'No websocket messages for 90 seconds'}
                if(-not $receive.Wait(200)){continue}
                $frame=$receive.GetAwaiter().GetResult()
                if($frame.MessageType -eq [Net.WebSockets.WebSocketMessageType]::Close){throw 'Exchange closed websocket'}
                $memory.Write($buffer,0,$frame.Count)
                if($memory.Length -gt 4194304){throw 'Websocket frame exceeds 4 MiB'}
                if($frame.EndOfMessage) {
                    $text=[Text.Encoding]::UTF8.GetString($memory.ToArray());$memory.SetLength(0);$last=$now
                    if($text.Contains('::ping::')){Send-WS $socket ($text.Replace('::ping::','::pong::'))}
                    elseif($text.StartsWith('{')) {
                        $raw=$text|ConvertFrom-Json
                        if($raw.error -or ($raw.response_type -eq 'ERROR')){throw "Subscription rejected: $text"}
                        foreach($trade in (Get-TradeRows $venue $raw)) {
                            if(-not $allowed.ContainsKey($trade.base) -or [string]::IsNullOrEmpty($trade.id)){continue}
                            if(Store-Trade $venue $trade $connected $now $shared){$confirmed=$true; $retry=1}
                        }
                    }
                    $shared.Feeds[$key]=@{venue=$venue;state=$(if($confirmed){'LIVE'}else{'WAITING'});since=$connected;at=$now;error=''}
                }
                $receive=$socket.ReceiveAsync([ArraySegment[byte]]::new($buffer),[Threading.CancellationToken]::None)
                if($now-$cleanup -ge 60){foreach($id in @($dedup.Keys)){if($dedup[$id] -lt $now-180){$removed=0L;[void]$dedup.TryRemove($id,[ref]$removed)}};$cleanup=$now}
            }
        } catch {
            $message=$_.Exception.Message
            $shared.Feeds[$key]=@{venue=$venue;state='ERROR';since=0;at=(Now-Seconds);error=$message}
            $shared.Errors.Enqueue("$key websocket: $message")
        } finally {$socket.Abort();$socket.Dispose();$cts.Dispose();if($memory){$memory.Dispose()}}
        for($i=0;$i -lt $retry*10 -and -not $shared.Stop;$i++){Start-Sleep -Milliseconds 100}
        $retry=[Math]::Min(30,$retry*2)
    }
}
