param([int]$Port=20560,[switch]$NoBrowser)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
. "$root/workers.ps1"
. "$root/model.ps1"
$web=[IO.Path]::GetFullPath((Join-Path $root 'web'))
if(-not (Test-Path "$web/index.html")){throw 'Missing web/index.html. Extract the entire ZIP first.'}
$logDir=Join-Path $root 'logs';[void][IO.Directory]::CreateDirectory($logDir)
$log=Join-Path $logDir 'runtime.log'
function Log($message){$line="$(Get-Date -Format o) $message";[IO.File]::AppendAllText($log,$line+[Environment]::NewLine);Write-Host $line}
$script:LiveCache=@{}
$shared=[hashtable]::Synchronized(@{Stop=$false;Tickers=[Collections.Concurrent.ConcurrentDictionary[string,object]]::new();Feeds=[Collections.Concurrent.ConcurrentDictionary[string,object]]::new();Buckets=@{};Seen=@{};Retained=[Collections.Concurrent.ConcurrentDictionary[string,long]]::new();Errors=[Collections.Concurrent.ConcurrentQueue[string]]::new()})
foreach($v in $Venues){$shared.Buckets[$v]=[Collections.Concurrent.ConcurrentDictionary[string,object]]::new();$shared.Seen[$v]=[Collections.Concurrent.ConcurrentDictionary[string,long]]::new();$shared.Retained[$v]=Now-Seconds}
$jobs=[Collections.Generic.List[object]]::new()
$workerSource=[IO.File]::ReadAllText("$root/workers.ps1")
function Start-Worker($kind,$venue,$markets,$key){
    $runspace=[RunspaceFactory]::CreateRunspace();$runspace.Open()
    $ps=[PowerShell]::Create();$ps.Runspace=$runspace
    $code='param($kind,$venue,$markets,$key,$shared)' + [Environment]::NewLine + $workerSource + [Environment]::NewLine + 'if($kind -eq "ticker"){Run-Ticker $venue $shared}else{Run-Trades $venue $markets $key $shared}'
    [void]$ps.AddScript($code).AddArgument($kind).AddArgument($venue).AddArgument($markets).AddArgument($key).AddArgument($shared)
    $task=$ps.BeginInvoke();$jobs.Add(@{ps=$ps;space=$runspace;task=$task;kind=$kind;venue=$venue;key=$key})
}
function Parse-Query($uri){$q=@{};foreach($pair in $uri.Query.TrimStart('?').Split('&')){if(-not $pair){continue};$parts=$pair.Split('=',2);$q[[Uri]::UnescapeDataString($parts[0])]=if($parts.Length -gt 1){[Uri]::UnescapeDataString($parts[1].Replace('+',' '))}else{''}};return $q}
function Write-Response($stream,$status,$mime,[byte[]]$bytes){
    $header="HTTP/1.1 $status`r`nContent-Type: $mime`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n`r`n"
    $head=[Text.Encoding]::ASCII.GetBytes($header);$stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length);$stream.Flush()
}
function Json-Response($stream,$status,$value){Write-Response $stream $status 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $value -Depth 25 -Compress)))}
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port)
$started=@{};$lastCleanup=0;$lastCache=0;$lastRegistry=0
try {
    $listener.Start()
    Log "MarketGO PowerShell $($PSVersionTable.PSVersion); local URL http://127.0.0.1:$Port/; notice collection OFF"
    foreach($venue in $Venues){Start-Worker 'ticker' $venue @() "ticker-$venue"}
    if(-not $NoBrowser){Start-Process "http://127.0.0.1:$Port/"}
    while(-not $shared.Stop){
        $now=Now-Seconds
        if($now -ne $lastCache){$script:LiveCache=@{};$lastCache=$now}
        $message=$null
        while($shared.Errors.TryDequeue([ref]$message)){Log $message}
        if($now-$lastRegistry -ge 5){foreach($venue in $Venues){
            $ticker=$shared.Tickers[$venue]
            $fingerprint=(@($ticker.rows|ForEach-Object {$_.symbol}|Sort-Object) -join ',')
            if($started[$venue] -ne $fingerprint -and $ticker -and -not $ticker.error -and $ticker.rows.Count -gt 0){
                foreach($job in @($jobs.ToArray())){if($job.kind -eq 'trade' -and $job.venue -eq $venue){$job.ps.Stop();$job.ps.Dispose();$job.space.Dispose();[void]$jobs.Remove($job);$removed=$null;[void]$shared.Feeds.TryRemove($job.key,[ref]$removed)}}
                $markets=@($ticker.rows);$chunkSize=200;if($venue -eq 'coinone'){$chunkSize=100};if($venue -eq 'gopax'){$chunkSize=50}
                for($i=0;$i -lt $markets.Count;$i+=$chunkSize){$end=[Math]::Min($markets.Count-1,$i+$chunkSize-1);$chunk=@($markets[$i..$end]);Start-Worker 'trade' $venue $chunk "$venue-$i"}
                $started[$venue]=$fingerprint;Log "$venue official ticker received: $($markets.Count) KRW markets; websocket workers started"
            }
        };$lastRegistry=$now}
        if($now-$lastCleanup -ge 60){
            foreach($venue in $Venues){
                $buckets=$shared.Buckets[$venue];$cutoff=$now-86400
                if($buckets.Count -gt 100000){$ordered=@($buckets.Keys|Sort-Object);$cutoff=[Math]::Max($cutoff,[long]$ordered[$ordered.Count-90000].Split('|')[0]+1);Log "$venue retention bounded by memory budget"}
                $shared.Retained[$venue]=[Math]::Max($shared.Retained[$venue],$cutoff)
                foreach($key in @($buckets.Keys)){if([long]$key.Split('|')[0] -lt $cutoff){$removed=$null;[void]$buckets.TryRemove($key,[ref]$removed)}}
            }
            if((Get-Item $log).Length -gt 5242880){Copy-Item $log "$log.previous" -Force;[IO.File]::WriteAllText($log,'')}
            $lastCleanup=$now
        }
        if(-not $listener.Pending()){Start-Sleep -Milliseconds 10;continue}
        $client=$listener.AcceptTcpClient();$client.ReceiveTimeout=3000;$client.SendTimeout=5000
        $stream=$client.GetStream()
        try {
            $reader=[IO.StreamReader]::new($stream,[Text.Encoding]::ASCII,$false,1024,$true)
            $line=$reader.ReadLine();if(-not $line){continue}
            $parts=$line.Split(' ');if($parts[0] -ne 'GET'){Json-Response $stream '405 Method Not Allowed' @{detail='Only GET is allowed'};continue}
            $headers=@{};$size=$line.Length
            while($line=$reader.ReadLine()){$size+=$line.Length;if($size -gt 16384){throw 'HTTP headers too large'};$colon=$line.IndexOf(':');if($colon -gt 0){$headers[$line.Substring(0,$colon).ToLowerInvariant()]=$line.Substring($colon+1).Trim()}}
            if($headers.host -notin @("127.0.0.1:$Port","localhost:$Port")){Json-Response $stream '403 Forbidden' @{detail='Local host only'};continue}
            $uri=[uri]("http://127.0.0.1:$Port"+$parts[1]);$query=Parse-Query $uri
            switch($uri.AbsolutePath){
                '/api/portable/status' {Json-Response $stream '200 OK' @{engine='powershell';version=2;at=$now};break}
                '/api/portable/state' {Json-Response $stream '200 OK' (Get-State $query $shared);break}
                '/api/market-share/index-day' {
                    $answer=Get-TickerIndex $query $shared
                    if($query.projection -eq 'domestic_grid'){$answer=@{contract_version='INDEX_DAY_GRID_V1';day=$answer.day;status=$answer.status;storage_mode=$answer.storage_mode;domestic=$answer.domestic}}
                    Json-Response $stream '200 OK' $answer;break
                }
                '/api/market-share/realtime-index' {Json-Response $stream '200 OK' (Get-RealtimeIndex $query $shared);break}
                '/api/market-share/index-filters' {Json-Response $stream '200 OK' (Get-Filters $shared);break}
                default {
                    if($uri.AbsolutePath.StartsWith('/api/')){Json-Response $stream '404 Not Found' @{detail='Unsupported API'};break}
                    $relative=[uri]::UnescapeDataString($uri.AbsolutePath).TrimStart('/').Replace('/',[IO.Path]::DirectorySeparatorChar)
                    if(-not $relative){$relative='index.html'}
                    $path=[IO.Path]::GetFullPath((Join-Path $web $relative))
                    if(-not $path.StartsWith($web+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or -not [IO.File]::Exists($path)){Json-Response $stream '404 Not Found' @{detail='Asset not found'};break}
                    $types=@{'.html'='text/html; charset=utf-8';'.js'='text/javascript; charset=utf-8';'.css'='text/css; charset=utf-8';'.woff2'='font/woff2';'.svg'='image/svg+xml';'.png'='image/png';'.ico'='image/x-icon';'.json'='application/json'}
                    $mime=$types[[IO.Path]::GetExtension($path)];if(-not $mime){$mime='application/octet-stream'}
                    Write-Response $stream '200 OK' $mime ([IO.File]::ReadAllBytes($path))
                }
            }
        } catch {Log "HTTP: $($_.Exception.Message)";try{Json-Response $stream '503 Service Unavailable' @{detail=$_.Exception.Message}}catch{}}
        finally {$stream.Dispose();$client.Dispose()}
    }
} catch {Log "FATAL: $($_.Exception.Message)";throw}
finally {
    $shared.Stop=$true;$listener.Stop()
    foreach($job in $jobs){try{$job.ps.Stop();$job.ps.Dispose();$job.space.Dispose()}catch{}}
}
