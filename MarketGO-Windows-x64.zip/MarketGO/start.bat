@echo off
setlocal
title MarketGO Portable
pushd "%~dp0" || exit /b 1
if not exist "marketgo.exe" goto missing
if not exist "web\index.html" goto missing
for /f "tokens=1 delims==" %%G in ('set MARKET_SHARE_ 2^>nul') do set "%%G="
set "MARKET_SHARE_STORAGE_MODE=sqlite-memory"
set "MARKET_SHARE_DEPLOYMENT_MODE=standalone"
set "MARKET_SHARE_LLM_ENABLED=false"
set "MARKET_SHARE_NOTICE_ENABLED=false"
set "MARKET_SHARE_HERMES_NOTICE_AUTOSTART=false"
set "MARKET_SHARE_FRONTEND_ROOT=%CD%\web"
set "MARKET_SHARE_OPEN_BROWSER=true"
set "MARKET_SHARE_API_HOST=127.0.0.1"
set "MARKET_SHARE_API_PORT=20560"
if not exist "logs" mkdir "logs"
echo Starting MarketGO Portable...
echo The browser will open automatically when ready.
echo Local address: http://127.0.0.1:20560/
echo Keep this window open. Press Ctrl+C to stop.
echo Log file: logs\runtime.log
"%CD%\marketgo.exe" > "logs\runtime.log" 2>&1
set "result=%ERRORLEVEL%"
if not "%result%"=="0" (
  echo MarketGO stopped. See the error below:
  type "logs\runtime.log"
  pause
)
popd
exit /b %result%
:missing
echo Extract the entire ZIP before running start.bat.
echo marketgo.exe and the web folder must be beside start.bat.
pause
popd
exit /b 1
