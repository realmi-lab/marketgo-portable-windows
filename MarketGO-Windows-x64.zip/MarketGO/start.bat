@echo off
setlocal
set "MARKETGO_START_DIR=%~dp0"
title MarketGO Portable - PowerShell
pushd "%~dp0" || exit /b 1
if not exist "server.ps1" goto missing
if not exist "web\index.html" goto missing
if not exist "logs" mkdir "logs"
echo Starting MarketGO Portable - no bundled EXE required.
echo The browser will open automatically.
echo Keep this window open. Press Ctrl+C to stop collection.
echo Logs: logs\runtime.log and logs\launcher.log
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%CD%\server.ps1" > "logs\launcher.log" 2>&1
set "result=%ERRORLEVEL%"
if not "%result%"=="0" (
  echo PowerShell stopped. Please share the error below:
  type "logs\launcher.log"
  pause
)
popd
exit /b %result%
:missing
echo Extract the entire ZIP before running start.bat.
echo server.ps1 and the web folder must be beside start.bat.
pause
popd
exit /b 1
